public class Pastry extends Cake{
    public void display(){
        System.out.println(name+": ₹ "+price+" per piece");
    }

}
