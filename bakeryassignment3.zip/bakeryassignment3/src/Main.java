import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        Cake cke1=new Cake();
        Cake cke2=new Cake();

        cke1.setName("Chocolate Brownie");
        cke1.setPrice(250);
        cke2.setName("Chocolate Maple");
        cke2.setPrice(300);
        ArrayList<Cake> list=new ArrayList<>();
        list.add(cke1);
        list.add(cke2);

        Pastry pst1=new Pastry();
        Pastry pst2=new Pastry();

        pst1.setName("Black Forest");
        pst1.setPrice(35);
        pst2.setName("Choco Truffle");
        pst2.setPrice(40);
        ArrayList<Pastry> pstrList=new ArrayList<>();

        pstrList.add(pst1);
        pstrList.add(pst2);

        System.out.println("           Today's Special Menu");
        System.out.println("-------------------------------------------");
        System.out.println();
        System.out.println("Special Cakes");
        System.out.println("---------------------------------------");

        for (Cake e:
             list) {
            e.display();
        }
        System.out.println();

        System.out.println("Special Pastries");
        System.out.println("---------------------------------------");

        for (Pastry e:
                pstrList) {
            e.display();
        }

    }
}