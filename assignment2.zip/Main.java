/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    public static long calculateTax(String name, long income){
       long tax=0;
       
            if(income>=300000){
                tax=(income*20)/100;
            }else if(income>=100000 && income<300000){
                tax=(income*10)/100;
            }else if(income<100000){
                tax=0;
            }
        return tax;
        
    }
	public static void main(String[] args) {
	    
		System.out.println("TAX Calculator App");
		System.out.println("------WELCOME------");
		System.out.println("Enter total person count:");
		Scanner sc=new Scanner(System.in);
		int person=sc.nextInt();
		String[] name=new String[person];
		long income[]=new long[person];
		for(int i=1;i<=person;i++){
		    System.out.println("Enter name "+i);
		    name[i-1]=sc.next();
		    System.out.println("Enter "+name[i-1]+"'s Annual Income");
		    income[i-1]=sc.nextLong();
		    System.out.println("");
		}
		System.out.println("Names with liable taxes");
		System.out.println("-----------------------");
		for(int i=0;i<person;i++){
		    	System.out.println(name[i]+" : ₹"+calculateTax(name[i],income[i]));
		}
	
		
	}
}
