/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
	    System.out.println("Enter student's name: ");
		String name=sc.nextLine();
		System.out.println("Enter student's age: ");
		int age=sc.nextInt();
		System.out.println("Enter student's blood group: ");
		String bloodGroup=sc.next();
		String group=" ";
		if(age>=20) group="RED";
		else if(age>=15 && age<20) group="BLUE";
		else if(age>=10 && age<15) group="YELLOW";
		
	    System.out.println("----------------------------");
	    System.out.println("    Name: "+name);
	    System.out.println("    Age: "+age);
	    System.out.println("    Blood Group: "+bloodGroup);
	    
	    System.out.println("----------------------------");
	    System.out.println("    Your group is "+group);
	    System.out.println("----------------------------");
	}
}
